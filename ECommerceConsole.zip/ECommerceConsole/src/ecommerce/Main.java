package ecommerce;

import java.util.Scanner;

public class Main {

    public static User login(UserManager um, Scanner input) {
        System.out.print("Username: ");
        String u = input.nextLine();
        System.out.print("Password: ");
        String p = input.nextLine();

        User user = um.login(u, p);
        if (user == null) {
            System.out.println("Login gagal.");
        } else {
            System.out.println("Login berhasil sebagai " + user.getUsername());
        }
        return user;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ProductManager pm = new ProductManager();
        TransactionManager tm = new TransactionManager();
        Cart cart = new Cart();
        UserManager um = new UserManager();

        pm.addProduct(new Clothing("Kaos Polos", 50000, 10));
        pm.addProduct(new Electronics("Headset", 150000, 5));
        pm.addProduct(new Electronics("Laptop", 7000000, 2));

        System.out.println("=== LOGIN ===");
        User currentUser = login(um, input);
        if (currentUser == null) return;

        int pilihan;
        do {
            System.out.println("\n=== E-Commerce Menu ===");
            System.out.println("1. Lihat Produk");
            System.out.println("2. Tambah ke Keranjang");
            System.out.println("3. Lihat Keranjang");
            System.out.println("4. Checkout");
            System.out.println("0. Keluar");
            System.out.print("Pilihan: ");
            pilihan = input.nextInt(); input.nextLine();

            switch (pilihan) {
                case 1:
                    System.out.println("\nDaftar Produk:");
                    for (Product p : pm.getAllProducts()) {
                        System.out.println("- " + p);
                    }
                    break;

                case 2:
                    System.out.print("Nama Produk: ");
                    String namaBeli = input.nextLine();
                    Product p = pm.findByName(namaBeli);
                    if (p == null) {
                        System.out.println("Produk tidak ditemukan!");
                        break;
                    }

                    System.out.print("Jumlah: ");
                    int qty = input.nextInt();
                    if (p.getStock() < qty) {
                        System.out.println("Stok tidak cukup!");
                        break;
                    }

                    cart.addItem(p, qty);
                    System.out.println("Produk ditambahkan ke keranjang.");
                    break;

                case 3:
                    System.out.println("\n=== Keranjang Belanja ===");
                    for (CartItem item : cart.getItems()) {
                        System.out.println("- " + item);
                    }
                    System.out.println("Total: Rp" + cart.getTotal());
                    break;

                case 4:
                    double bayar = cart.getTotal();
                    System.out.println("Total Bayar: Rp" + bayar);
                    System.out.print("Konfirmasi bayar? (y/n): ");
                    String konfirm = input.nextLine();

                    if (konfirm.equalsIgnoreCase("y")) {
                        for (CartItem item : cart.getItems()) {
                            tm.buyProduct(item.getProduct(), item.getQuantity());
                        }
                        cart.clear();
                        System.out.println("Transaksi selesai.");
                    } else {
                        System.out.println("Checkout dibatalkan.");
                    }
                    break;

                case 0:
                    System.out.println("Terima kasih telah menggunakan aplikasi.");
                    break;

                default:
                    System.out.println("Pilihan tidak valid.");
            }
        } while (pilihan != 0);
    }
}
