# 🛒 E-Commerce Console App (Java)

Aplikasi e-commerce berbasis **Java Console** yang memungkinkan pengguna untuk melakukan login, melihat produk, menambahkan produk ke keranjang, dan melakukan checkout. Dibuat menggunakan prinsip **Object-Oriented Programming (OOP)**.

## ✨ Fitur Utama

✅ Multi-user login (dengan username & password)  
✅ Menampilkan daftar produk  
✅ Menambahkan produk ke keranjang  
✅ Checkout keranjang  
✅ Validasi stok saat pembelian

## 🔐 Login Info (Data Default)

| Username | Password |
|----------|----------|
| admin    | 123      |
| natan    | abc      |

Kamu bisa menambahkan lebih banyak user di file `UserManager.java`.

## 🚀 Cara Menjalankan Proyek

1. Buka proyek di NetBeans / IDE Java
2. Masukkan semua file ke dalam package `ecommerce`
3. Jalankan file `Main.java`
4. Login menggunakan akun yang tersedia
5. Ikuti menu pada terminal
